package co.aquaapps.huddle.api;

@SuppressWarnings("unused")
public class HuddleApi {
    public static final String HUDDLE_API_INTENT = "co.aquaapps.huddle.directionchanged";

    public static final String KEY_ETA_TIME = "eta_time";                               // Estimated Time of Arrival                    e.g. "3:58"
    public static final String KEY_ETA_AMPM = "eta_ampm";                               // ETA: "am" or "pm                             e.g. "pm"
    public static final String KEY_DISTANCE = "distance_metres";                        // Distance to next nav direction in METRES     e.g. 100
    public static final String KEY_ICON = "direction_icon";                             // Next nav direction icon                      e.g. HuddleApi.DIRECTION_TURN_RIGHT
    public static final String KEY_REMAINING_DISTANCE = "remaining_distance_metres";    // Total remaining distance in METRES           e.g. 1200
    public static final String KEY_REMAINING_TIME = "remaining_time_seconds";           // Total remaining time in SECONDS              e.g. 60

    /* TODO Example Intent
        Intent huddleIntent = new Intent(HuddleApi.HUDDLE_API);
        huddleIntent.putStringExtra(HuddleApi.KEY_ETA_TIME, "3:58");
        huddleIntent.putStringExtra(HuddleApi.KEY_ETA_AMPM, "pm");
        huddleIntent.putLongExtra(HuddleApi.KEY_DISTANCE, 100);
        huddleIntent.putLongExtra(HuddleApi.KEY_REMAINING_DISTANCE, 1000);
        huddleIntent.putLongExtra(HuddleApi.KEY_REMAINING_TIME, 60);
        huddleIntent.putIntExtra(HuddleApi.KEY_ICON, HuddleApi.DIRECTION_UNKNOWN);
        sendBroadcast(huddleIntent);
    */

    public static final int DIRECTION_UNKNOWN = -1;
    public static final int DIRECTION_TURN_RIGHT = 0;
    public static final int DIRECTION_TURN_SHARP_RIGHT = 1;
    public static final int DIRECTION_LANE_SWITCH_RIGHT = 2;
    public static final int DIRECTION_DIRECTION_STRAIGHT = 3;
    public static final int DIRECTION_LANE_STUB = 4;
    public static final int DIRECTION_TURN_UTURN = 5;
    public static final int DIRECTION_LANE_GUIDANCE_TICK = 6;
    public static final int DIRECTION_ARRIVE_RIGHT = 7;
    public static final int DIRECTION_ARRIVE = 8;
    public static final int DIRECTION_DEPART = 9;
    public static final int DIRECTION_FORK_RIGHT = 10;
    public static final int DIRECTION_MERGE = 11;
    public static final int DIRECTION_ROUNDABOUT_GENERIC = 12;
    public static final int DIRECTION_MISCELLANEOUS_LOCATION = 13;
    public static final int DIRECTION_RAMP_EXIT_RIGHT = 14;
    public static final int DIRECTION_ROUNDABOUT_1 = 15;
    public static final int DIRECTION_ROUNDABOUT_2 = 16;
    public static final int DIRECTION_ROUNDABOUT_3 = 17;
    public static final int DIRECTION_ROUNDABOUT_4 = 18;
    public static final int DIRECTION_ROUNDABOUT_5 = 19;
    public static final int DIRECTION_ROUNDABOUT_6 = 20;
    public static final int DIRECTION_ROUNDABOUT_7 = 21;
    public static final int DIRECTION_ROUNDABOUT_8 = 22;
    public static final int DIRECTION_ROUNDABOUT_EXIT = 23;
    public static final int DIRECTION_TURN_SLIGHT_RIGHT = 24;
    public static final int DIRECTION_TURN_UTURN_FLIPPED = 25;
    public static final int DIRECTION_TURN_LEFT = 26;
    public static final int DIRECTION_TURN_SHARP_LEFT = 27;
    public static final int DIRECTION_LANE_SWITCH_LEFT = 28;
    public static final int DIRECTION_ARRIVE_LEFT = 29;
    public static final int DIRECTION_FORK_LEFT = 30;
    public static final int DIRECTION_ROUNDABOUT_GENERIC_FLIPPED = 31;
    public static final int DIRECTION_RAMP_EXIT_LEFT = 32;
    public static final int DIRECTION_ROUNDABOUT_1_FLIPPED = 33;
    public static final int DIRECTION_ROUNDABOUT_2_FLIPPED = 34;
    public static final int DIRECTION_ROUNDABOUT_3_FLIPPED = 35;
    public static final int DIRECTION_ROUNDABOUT_4_FLIPPED = 36;
    public static final int DIRECTION_ROUNDABOUT_5_FLIPPED = 37;
    public static final int DIRECTION_ROUNDABOUT_6_FLIPPED = 38;
    public static final int DIRECTION_ROUNDABOUT_7_FLIPPED = 39;
    public static final int DIRECTION_ROUNDABOUT_8_FLIPPED = 40;
    public static final int DIRECTION_ROUNDABOUT_EXIT_FLIPPED = 41;
    public static final int DIRECTION_TURN_SLIGHT_LEFT = 42;
}